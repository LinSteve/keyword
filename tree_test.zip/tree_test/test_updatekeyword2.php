<?php 
header("Content-type:text/html;charset=utf-8");

ini_set("display_errors", 1);

error_reporting(E_ALL ^ E_NOTICE);

error_reporting(E_ALL ^ E_WARNING);

		
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		//	echo "HTTP_CLIENT_IP:".$ip;
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		//	echo "HTTP_X_FORWARDED_FOR:".$ip;
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		//	echo "REMOTE_ADDR:".$ip;
		}


		$parm = $_POST['keyword'];//關鍵字組
		$item_name = '{"keyword":"'.$parm.'"}';
		$ch = curl_init();
		curl_setopt_array($ch, array(
		  CURLOPT_URL => 'http://104.208.85.199:8086/api/v1/keyword',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>$item_name,
		  CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json',
			'Authorization: Bearer evCXnzuA7MNKPp35uMcoZbitadlTSsfQ'
		  ),
		));
/*		
*/		$result = curl_exec($ch);
		curl_close($ch);
		
		$obj = json_decode($result,true); //true:Array、false:Object
		
		//获取网址
			if($_SERVER["SERVER_PORT"]=="80" or $_SERVER["SERVER_PORT"]==""){
				$url=$_SERVER['SERVER_NAME'];
			}else{
				$url=$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"];
			}	
			$url= 'keyword.lgood94.com.tw';
			echo '<font style="display:block; font-size:14px; color:#030ffc;"><a href="http://'.$url.'/update_keyword.php'.'" target="_parent" style="color:#030ffc;">返回</a></font>';	
		

		echo "<p>&nbsp;</p>";
		print_r($result);
		echo "<br/><br/>"; 
	//	echo "The Result : ".$result;
	//	echo var_dump($result);   
	//	echo "<br/>";   
		echo "<pre>"; 			
		print_r($obj);   
		echo "<pre/>";  

	foreach($obj['data'][0]['updated'] as $k => $m) {
		echo "k->".$k;
		echo "<br/>";
		echo "m->".$m;
		echo "<br/>";
			
	}
	//PDO BUILD CONNECTION
	require_once('config/db.php');
	
	$now_time = date('Y-m-d H:i:s');
	foreach($obj['data'][0]['updated'] as $k => $val) {
		$keyword_tmp = $val;
		$keyword_cnt = $k + 1;
		$sql = "INSERT INTO `twcms_keywordpost` (`keyword`, `sno`, `add_date`) 
				VALUES ('{$keyword_tmp}', '{$keyword_cnt}', '{$now_time}')";
		$flag = $PDOLink->exec($sql);
	}
	
/*	if($flag !== false) {
		
		header('Location: ../news.php?success=2');
	} else {
		header('Location: ../news.php?error=2');
	}*/
?>