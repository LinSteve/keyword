<?php 
header("Content-type:text/html;charset=utf-8");

ini_set("display_errors", 0);

error_reporting(E_ALL ^ E_NOTICE);

error_reporting(E_ALL ^ E_WARNING);
	$DB_Server = "localhost"; // MySQL Server
	$DB_Username = "root"; // MySQL Username
	$DB_Password = "A0975382327z!@#$"; // MySQL Password
	$DB_DBName = "keyworddb"; // MySQL Database Name
	include("adodb/adodb.inc.php");
	$conn = ADONewConnection('mysql'); # eg 'mysql' or 'postgres'
	$conn->debug = false;
	$conn->Connect("localhost", "root", "A0975382327z!@#$", "keyworddb");
	$conn->query("SET NAMES 'big5'");
	if (!$conn) {echo "無法連接資料庫 db1";}
		
	$dbconn = @mysql_connect($DB_Server, $DB_Username, $DB_Password) or die("Failed to connect to MySQL:<br />" . mysql_error() . "<br />" . mysql_errno());
	mysql_query("SET NAMES 'big5'");
	// Select database
	$Db = @mysql_select_db($DB_DBName, $dbconn) or die("Failed to select database:<br />" . mysql_error(). "<br />" . mysql_errno());
	$sql = "DELETE FROM twcms_keyword";
	@mysql_query($sql,$dbconn) or die("Failed to execute query:<br />" . mysql_error(). "<br />" . mysql_errno());

	require_once('../config/db.php');
		
	$id = $_GET['keyword_id'];//台積電
	$sql = "SELECT * FROM `twcms_keywordpost` WHERE id = '{$id}'";
	$rs  = $PDOLink->prepare($sql);
	$rs->execute();
	$rec = $rs->fetch();
	if($rec == '') {
		// header('Location: curfew-editschedule.php?error=2');
		echo "<script>location.replace('../index.php')</script>";
		exit;
	}
	$reserve_keyword = $rec['keyword'];
	$item_name = $rec['keyword'];//台積電
	//URL method:GET
	$gateway_url = "http://104.208.85.199:8086/api/v1/corr";
	$hash_key = "evCXnzuA7MNKPp35uMcoZbitadlTSsfQ";

		$dingdanhao = date("Y-m-dH-i-s");
		$dingdanhao = str_replace("-","",$dingdanhao);
		$dingdanhao .= rand(100,999);
	//	echo "dingdanhao：".$dingdanhao;
	//	echo "<br/>";
		$gateway_url = "http://104.208.85.199:8086/api/v1/corr?keyword=".$item_name."&accessToken=".$hash_key;
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $gateway_url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		curl_close($ch);
		
		$data = json_decode($result,true); //true:Array、false:Object
		$index = 0;		
				
			$rs = $conn->Execute("select * from twcms_keyword");
			$record = array();
			$name = iconv("UTF-8","BIG5", $item_name);
			$record["keyword"] 		= $name;
			$record["correlation"] 	= 0;
			$record["parent_id"] 	= 0;	
			$record["add_date"] 	= date('Y-m-d H:i:s');
			$insertSQL = $conn->GetInsertSQL($rs, $record);
			$conn->Execute($insertSQL); # Insert the record into the database
			$lastId0 = $conn->insert_Id();
			mysql_query('select * from twcms_keyword');
			
		foreach($data['data'] as $k=>$data_item)
		{ 
			if($k>=5) break;
			$record = array();
			$name = iconv("UTF-8","BIG5", $data_item['keyword']);
			$record["keyword"] 		= $name;
			$record["correlation"] 	= $data_item['correlation'];
			$record["parent_id"] 	= $lastId0;	
			$record["add_date"] 	= date('Y-m-d H:i:s');
			$insertSQL = $conn->GetInsertSQL($rs, $record);
			$conn->Execute($insertSQL); # Insert the record into the database
			$lastId = $conn->insert_Id();
			mysql_query('select * from twcms_keyword');
			$index += 1;
			if($index <= 5){
				$item_name = $data_item['keyword']; 
				$gateway_url = "http://104.208.85.199:8086/api/v1/corr?keyword=".$item_name."&accessToken=".$hash_key;
				$ch = curl_init();
				
				curl_setopt($ch, CURLOPT_URL, $gateway_url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$result = curl_exec($ch);
				curl_close($ch);
				
				$data2 = json_decode($result,true); //true:Array、false:Object
				$index2 = 0;
				foreach($data2['data'] as $k2=>$data_item2)
				{ 
					if($k2>=5) break;
					$record = array();
					$name = iconv("UTF-8","BIG5", $data_item2['keyword']);
					$record["keyword"] 		= $name;
					$record["correlation"] 	= $data_item2['correlation'];
					$record["parent_id"] 	= $lastId;	
					$record["add_date"] 	= date('Y-m-d H:i:s');
					$insertSQL = $conn->GetInsertSQL($rs, $record);
					$conn->Execute($insertSQL); # Insert the record into the database
					$lastId2 = $conn->insert_Id();
					mysql_query('select * from twcms_keyword');
					$index2 += 1;
					if($index2 <= 10){
						$item_name = $data_item2['keyword']; 
						$gateway_url = "http://104.208.85.199:8086/api/v1/corr?keyword=".$item_name."&accessToken=".$hash_key;
						$ch = curl_init();
						
						curl_setopt($ch, CURLOPT_URL, $gateway_url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						$result = curl_exec($ch);
						curl_close($ch);
						
						$data3 = json_decode($result,true); //true:Array、false:Object
						foreach($data3['data'] as $k3=>$data_item3)
						{ 
							if($k3>=5) break;
							$record = array();
							$name = iconv("UTF-8","BIG5", $data_item3['keyword']);
							$record["keyword"] 		= $name;
							$record["correlation"] 	= $data_item3['correlation'];
							$record["parent_id"] 	= $lastId2;	
							$record["add_date"] 	= date('Y-m-d H:i:s');
							$insertSQL = $conn->GetInsertSQL($rs, $record);
							$conn->Execute($insertSQL); # Insert the record into the database
							$lastId3 = $conn->insert_Id();
							mysql_query('select * from twcms_keyword');
						}
					}
				}
			}
		}
//****以下產生TREE DIAGRAM*//

$sql = "SELECT id, parent_id, keyword FROM twcms_keyword ORDER BY id asc";
$result = @mysql_query($sql,$dbconn) or die("Failed to execute query:<br />" . mysql_error(). "<br />" . mysql_errno());
//$data = mysql_fetch_array($result);
	$arr = array();
	$product = array();
	
while($data = mysql_fetch_array($result)) {
		$product["id"] = $data["id"];
		$product["parentid"] = $data["parent_id"];
		$name = iconv("BIG5","UTF-8", $data['keyword']);
		$product["name"] = $name;
		array_push($arr, $product);
	//	echo "<pre>"; 			
	//	print_r($data);   
	//	echo "<pre/>"; 	
	//	echo var_dump($data);   
	//	echo "<br/>";   
}
	
	
/*		echo "<pre>"; 			
		print_r($arr);   
		echo "<pre/>";  	
*/
$new = array();
foreach ($arr as $a){
    $new[$a['parentid']][] = $a;
}
$tree = createTree($new, array($arr[0]));
		//print_r($tree);
	//	echo "<pre>"; 			
	//	print_r($tree);   
	//	echo "<pre/>";  

$json_tree = json_encode($tree);
$json_tree = substr($json_tree, 1);//去頭
$json_tree = rtrim($json_tree, "]");//去尾
/*
$json_head='{
 "name": "flare",
"children": ';
$json_tail='}';
$json_head .= $json_tree;
$json_head .= $json_tail;
*/
//		echo "<pre>"; 			
//		echo var_dump($json_head);    
//		echo "<pre/>";
			$json_file_name = 'f' . rand(00000000, 99999999) . '.' . 'json';
			$json_file_name = 'jsondata/'. $json_file_name;
			
file_put_contents($json_file_name, $json_tree);
//file_put_contents($json_file_name, $json_head.json_encode($tree).$json_tail);

/* INSERT KEYWORDLOG */
/*$today = date('Y-m-d');
$sql = "SELECT * FROM twcms_keywordpost where add_date='$today' ORDER BY add_date,sno desc";
$result = @mysql_query($sql,$dbconn) or die("Failed to execute query:<br />" . mysql_error(). "<br />" . mysql_errno());
if( !$data = mysql_fetch_array($result)){
	$sno = 0;
}else{
	$sno = $data['sno'];
}*/
//	$name = iconv("UTF-8","BIG5", $rec['keyword']);
	$now_time = date('Y-m-d H:i:s');
	$sql = "UPDATE `twcms_keywordpost` SET `jsondata_path` = '{$json_file_name}', 
			`jsondata_content` = '{$json_tree}' WHERE `id` = '{$id}'";
	$flag = $PDOLink->exec($sql);
	
			//获取网址
			if($_SERVER["SERVER_PORT"]=="80" or $_SERVER["SERVER_PORT"]==""){
				$url=$_SERVER['SERVER_NAME'];
			}else{
				$url=$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"];
			}			
echo '<font style="display:block; font-size:14px; color:#c30008;"><a href="http://'.$url.'/tree_test/index.php?jsonfilename='.$json_file_name.'" target="_parent" style="color:#c30008;">'.'查看D3.js樹狀圖'.'</a></font>';	
echo '<font style="display:block; font-size:14px; color:#030ffc;"><a href="http://'.$url.'" target="_parent" style="color:#030ffc;">'.'返回'.'</a></font>';	
function createTree(&$list, $parent){
	$tree = array();
	
	foreach ($parent as $k=>$l){
		if(isset($list[$l['id']])){
            $l['children'] = createTree($list, $list[$l['id']]);
        }
     //   $tree[] = $l;
		$tree[] = array('name'=>$l['name'],'children'=>$l['children']);
	} 
	
    return $tree;
}

?>