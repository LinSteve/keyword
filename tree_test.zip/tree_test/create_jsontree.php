<?php
header("Content-Type:text/html; charset=utf-8");
ini_set("display_errors", 1);

error_reporting(E_ALL ^ E_NOTICE);

error_reporting(E_ALL ^ E_WARNING);
$DB_Server = "db01.coowo.com"; // MySQL Server
$DB_Username = "keyword"; // MySQL Username
$DB_Password = "A0975382327z!@#$"; // MySQL Password
$DB_DBName = "keyworddb"; // MySQL Database Name
$dbconn = @mysql_connect($DB_Server, $DB_Username, $DB_Password) or die("Failed to connect to MySQL:<br />" . mysql_error() . "<br />" . mysql_errno());
mysql_query("SET NAMES 'big5'");
		// Select database
$Db = @mysql_select_db($DB_DBName, $dbconn) or die("Failed to select database:<br />" . mysql_error(). "<br />" . mysql_errno());
/*=============================================================================================================================*/		
$Xarr = array(
  array('id'=>100, 'parentid'=>0, 'name'=>'a'),
  array('id'=>101, 'parentid'=>100, 'name'=>'a'),
  array('id'=>102, 'parentid'=>101, 'name'=>'a'),
  array('id'=>103, 'parentid'=>101, 'name'=>'a'),
);
$sql = "SELECT id, parent_id, keyword FROM twcms_keyword ORDER BY id asc";
$result = @mysql_query($sql,$dbconn) or die("Failed to execute query:<br />" . mysql_error(). "<br />" . mysql_errno());
//$data = mysql_fetch_array($result);
	$arr = array();
	$product = array();
	
while($data = mysql_fetch_array($result)) {
		$product["id"] = $data["id"];
		$product["parentid"] = $data["parent_id"];
		$name = iconv("BIG5","UTF-8", $data['keyword']);
		$product["name"] = $name;
		array_push($arr, $product);
	//	echo "<pre>"; 			
	//	print_r($data);   
	//	echo "<pre/>"; 	
	//	echo var_dump($data);   
	//	echo "<br/>";   
}
	
	
		echo "<pre>"; 			
		print_r($arr);   
		echo "<pre/>";  	
//exit();
$new = array();
foreach ($arr as $a){
    $new[$a['parentid']][] = $a;
}
$tree = createTree($new, array($arr[0]));
		//print_r($tree);
		echo "<pre>"; 			
		print_r($tree);   
		echo "<pre/>";  
$json_tree = json_encode($tree);
$json_head='{
 "name": "flare",
"children": ';
$json_tail='}';
$json_head .= $json_tree;
$json_head .= $json_tail;
echo "<pre>"; 			
		echo var_dump($json_head);    
		echo "<pre/>";
//$json_file_name = 'jsondata/flare'.date("YmdHis") . '_' . rand(10000, 99999) . '.' . 'json';
file_put_contents('jsondata/flare.json', $json_head);
function createTree(&$list, $parent){
	$tree = array();
	
	foreach ($parent as $k=>$l){
		if(isset($list[$l['id']])){
            $l['children'] = createTree($list, $list[$l['id']]);
        }
     //   $tree[] = $l;
		$tree[] = array('name'=>$l['name'],'children'=>$l['children']);
	} 
	
    return $tree;
}
?>